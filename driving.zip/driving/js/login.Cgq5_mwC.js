const n=""+new URL("../img/login.D0KOFtQn.png",import.meta.url).href;export{n as l};
