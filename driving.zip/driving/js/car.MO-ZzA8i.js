const r=""+new URL("../img/car.DrSmG8Of.png",import.meta.url).href;export{r as _};
