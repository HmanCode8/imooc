import{b as e,e as r}from"./.pnpm.Bu5t9KzG.js";const s={__name:"ProcessAuditForArea",setup(t){return(o,a)=>(r(),e("div",null,"区域流程审核"))}};export{s as default};
