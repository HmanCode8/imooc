import{b as e,e as r}from"./.pnpm.Bu5t9KzG.js";const n={__name:"ProcessAuditForParking",setup(t){return(o,a)=>(r(),e("div",null,"停车场流程审核"))}};export{n as default};
