/**
 * 地图配置常量
 * 统一管理地图相关的配置参数
 */

// 投影坐标系配置
export const PROJECTION_CONFIG = {
  // 中国大地坐标系 2000
  CGCS2000: window.GLOBAL_CONFIG.MAP.CONFIG.CGCS2000,
  // Web Mercator (默认)
  WEB_MERCATOR: window.GLOBAL_CONFIG.MAP.CONFIG.WEB_MERCATOR
}

// 天地图服务配置
export const TIANDITU_CONFIG = {
  // 江苏天地图历史矢量服务 - 灰色
  JIANGSU_HISTORY_GREY: window.GLOBAL_CONFIG.MAP.LAYER_CONFIGS,
  // 江苏天地图历史矢量服务 - 蓝色
  JIANGSU_HISTORY_BLUE: {
    URL: 'http://jiangsu.tianditu.gov.cn/historyraster/rest/services/historyVector/js_sldt_blue/MapServer/WMTS',
    LAYER: 'historyVector_js_sldt_blue',
    MATRIX_SET: 'default',
    STYLE: 'default',
    FORMAT: 'image/png',
    TITLE: '历史矢量-蓝色'
  },
  // 江苏天地图历史矢量服务 - 黑色
  JIANGSU_HISTORY_BLACK: {
    URL: 'http://jiangsu.tianditu.gov.cn/historyraster/rest/services/historyVector/js_sldt_black/MapServer/WMTS',
    LAYER: 'historyVector_js_sldt_black',
    MATRIX_SET: 'default',
    STYLE: 'default',
    FORMAT: 'image/png',
    TITLE: '历史矢量-黑色'
  },
  // 影像服务
  JIANGSU_HISTORY_IMAGERY: {
    URL: 'https://jiangsu.tianditu.gov.cn/mapjs2/rest/services/MapJS/js_yxdt_latest/MapServer/WMTS',
    LAYER: 'MapJS_js_yxdt_latest',
    MATRIX_SET: 'default',
    STYLE: 'default',
    FORMAT: 'image/png',
    TITLE: '影像服务'
  }
}

// 地图服务类型配置
export const MAP_SERVICE_CONFIG = {
  // 极夜蓝风格
  POLAR_NIGHT: {
    type: 'wmts',
    config: TIANDITU_CONFIG.JIANGSU_HISTORY_BLUE,
    title: '极夜蓝风格'
  },

  // 暗夜黑风格
  DARK_NIGHT: {
    type: 'wmts',
    config: TIANDITU_CONFIG.JIANGSU_HISTORY_BLACK,
    title: '暗夜黑风格'
  },
  // 浅灰色风格
  LIGHT_GRAY: {
    type: 'wmts',
    config: TIANDITU_CONFIG.JIANGSU_HISTORY_GREY,
    title: '浅灰色风格'
  },
  // 影像风格
  IMAGERY: {
    type: 'wmts',
    config: TIANDITU_CONFIG.JIANGSU_HISTORY_IMAGERY,
    title: '影像风格'
  },
  // 3D风格
  THREE_D: {
    type: 'wmts',
    // config: TIANDITU_CONFIG.JIANGS U_HISTORY_IMAGERY,
    config: {},
    title: '3D风格'
  }
}

// 瓦片网格配置
export const TILE_GRID_CONFIG = {
  // 江苏地区范围
  EXTENT: window.GLOBAL_CONFIG.MAP.CONFIG.EXTENT,

  // 分辨率配置
  RESOLUTIONS: window.GLOBAL_CONFIG.MAP.CONFIG.RESOLUTIONS,

  // 原点配置
  ORIGIN: window.GLOBAL_CONFIG.MAP.CONFIG.ORIGIN
}

// 地图视图配置
export const VIEW_CONFIG = {
  // 默认中心点
  DEFAULT_CENTER: window.GLOBAL_CONFIG.MAP.CONFIG.DEFAULT_CENTER, // 江苏大致中心
  DEFAULT_ZOOM: window.GLOBAL_CONFIG.MAP.CONFIG.DEFAULT_ZOOM,

  // 最小/最大缩放级别
  MIN_ZOOM: window.GLOBAL_CONFIG.MAP.CONFIG.MIN_ZOOM,
  MAX_ZOOM: window.GLOBAL_CONFIG.MAP.CONFIG.MAX_ZOOM
}

// 地理位置配置
export const LOCATION_CONFIG = {
  // 主要城市坐标
  BEIJING: [116.3974, 39.9093],
  SHANGHAI: [121.4737, 31.2304],
  GUANGZHOU: [113.2644, 23.1291],
  SHENZHEN: [114.0579, 22.5431],
  NANJING: [118.7674, 32.0415],
  SUZHOU: [120.5853, 31.2989],
  WUXI: [120.3019, 31.4912],
  CHANGZHOU: [119.9465, 31.772],
  NANTONG: [120.8646, 32.0103],
  YANGZHOU: [119.4213, 32.3932],
  ZHENJIANG: [119.4528, 32.2044],
  TAIZHOU: [119.9152, 32.4849],
  SUQIAN: [118.2752, 33.963],
  XUZHOU: [117.1848, 34.2618],
  HUAIAN: [119.0213, 33.5975],
  YANCHENG: [120.1398, 33.3776],
  LIANYUNGANG: [119.1788, 34.6],

  // 江苏地区中心点
  JIANGSU: [119.0, 32.5]
}

// 地图样式配置
export const STYLE_CONFIG = {
  // 工具栏样式
  TOOLBAR: {
    POSITION: 'top-4 right-1/4',
    BACKGROUND: 'backdrop-blur-sm rounded-lg shadow-lg',
    PADDING: 'p-2',
    Z_INDEX: 'z-20',
    MARGIN: 'mr-1'
  },

  // 坐标显示样式
  COORDINATE_DISPLAY: {
    POSITION: 'bottom-4 left-1/4',
    TEXT_COLOR: 'text-black',
    BACKGROUND: 'px-3 py-2 rounded-lg',
    FONT: 'text-sm font-mono',
    Z_INDEX: 'z-20'
  },

  // 按钮样式
  BUTTON: {
    SIZE: 'w-8 h-8',
    ROUNDED: 'rounded',
    TRANSITION: 'hover:bg-blue-600',
    ZOOM_IN: 'bg-blue-500 text-white',
    ZOOM_OUT: 'bg-blue-500 text-white',
    LOCATE: 'bg-green-500 text-white hover:bg-green-600'
  }
}

// 默认配置
export const DEFAULT_CONFIG = {
  PROJECTION: PROJECTION_CONFIG.CGCS2000.CODE,
  PROJECTION_DEF: PROJECTION_CONFIG.CGCS2000.DEFINITION,
  TIANDITU: TIANDITU_CONFIG.JIANGSU_HISTORY_GREY,
  TILE_GRID: {
    EXTENT: TILE_GRID_CONFIG.JIANGSU_EXTENT,
    ORIGIN: TILE_GRID_CONFIG.ORIGIN,
    RESOLUTIONS: TILE_GRID_CONFIG.RESOLUTIONS
  },
  VIEW: {
    CENTER: VIEW_CONFIG.DEFAULT_CENTER,
    ZOOM: VIEW_CONFIG.DEFAULT_ZOOM
  },
  LOCATIONS: LOCATION_CONFIG,
  MAP_SERVICES: MAP_SERVICE_CONFIG
}
