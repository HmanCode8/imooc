<template>
  <div class="relative w-full h-full">
    <!-- 地图容器 -->
    <div ref="mapContainer" class="w-full h-full"></div>

    <!-- 工具栏 -->
    <div class="absolute top-4 right-[26%] backdrop-blur-sm rounded-lg shadow-lg p-2 z-20">
      <div class="flex flex-col gap-2">
        <div class="flex flex-col gap-1">
          <button @click="zoomIn" class="w-8 h-8 bg-blue-500 text-white rounded hover:bg-blue-600">+</button>
          <button @click="zoomOut" class="w-8 h-8 bg-blue-500 text-white rounded hover:bg-blue-600">-</button>
        </div>
        <button @click="locationBase" class="w-8 h-8 text-white bg-green-500 rounded hover:bg-green-600" title="回到默认位置">
          🏠
        </button>
      </div>
    </div>

    <!-- 坐标显示 -->
    <div
      class="absolute bottom-4 left-1/4 text-white px-3 py-2 rounded-lg text-sm font-mono z-20 ml-4  backdrop-blur-sm">
      <div> x:{{ currentCoords.longitude.toFixed(6) }} y:{{ currentCoords.latitude.toFixed(6) }}</div>
      <!-- <div>纬度: {{ currentCoords.latitude.toFixed(6) }}</div> -->
      <!-- <div class="text-xs text-gray-300">缩放: {{ currentZoom.toFixed(1) }}</div> -->
    </div>

  </div>
</template>

<script setup>
import { ref, onMounted, onUnmounted } from 'vue'
import { Map, View } from 'ol'
import TileLayer from 'ol/layer/Tile'
import WMTS from 'ol/source/WMTS'
import WMTSTileGrid from 'ol/tilegrid/WMTS'
import { fromLonLat, toLonLat } from 'ol/proj'
import proj4 from 'proj4'
import { register } from 'ol/proj/proj4'
import { get as getProjection } from 'ol/proj'
import 'ol/ol.css'
import { DEFAULT_CONFIG } from '../config/mapConfig.js'

const mapContainer = ref(null)
let map = null
const currentCoords = ref({ longitude: 119.0, latitude: 32.5 })
const currentZoom = ref(10)
const emits = defineEmits(['changeMapType'])
// 创建 WMTS 图层
const createWMTSLayer = (serviceConfig) => {
  const projection = getProjection(DEFAULT_CONFIG.PROJECTION)
  const matrixIds = DEFAULT_CONFIG.TILE_GRID.RESOLUTIONS.map((_, i) => i.toString())

  return new TileLayer({
    source: new WMTS({
      url: serviceConfig.URL,
      layer: serviceConfig.LAYER,
      matrixSet: serviceConfig.MATRIX_SET,
      style: serviceConfig.STYLE,
      format: serviceConfig.FORMAT,
      projection,
      tileGrid: new WMTSTileGrid({
        extent: DEFAULT_CONFIG.TILE_GRID.EXTENT,
        origin: DEFAULT_CONFIG.TILE_GRID.ORIGIN,
        resolutions: DEFAULT_CONFIG.TILE_GRID.RESOLUTIONS,
        matrixIds
      })
    })
  })
}

// 工具函数
const zoomIn = () => map?.getView().setZoom(map.getView().getZoom() + 1)
const zoomOut = () => map?.getView().setZoom(map.getView().getZoom() - 1)

const locationBase = () => {
  // 重新定位到默认位置
  map?.getView().setCenter(DEFAULT_CONFIG.VIEW.CENTER)
  map?.getView().setZoom(DEFAULT_CONFIG.VIEW.ZOOM)
}


const updateCoordinates = (event) => {
  if (!map) return

  let coords
  if (event && event.coordinate) {
    // 鼠标移动时的坐标 - 直接使用坐标值，因为地图已经使用EPSG:4490
    coords = event.coordinate
  } else {
    // 地图中心坐标
    const center = map.getView().getCenter()
    if (center) {
      coords = center
    }
  }

  if (coords) {
    currentCoords.value = {
      longitude: parseFloat(coords[0].toFixed(6)),
      latitude: parseFloat(coords[1].toFixed(6))
    }
  }
  currentZoom.value = map.getView().getZoom()
}

// 生命周期
onMounted(() => {
  if (mapContainer.value) {
    // 注册投影坐标系
    proj4.defs(DEFAULT_CONFIG.PROJECTION, DEFAULT_CONFIG.PROJECTION_DEF)
    register(proj4)
    const projection = getProjection(DEFAULT_CONFIG.PROJECTION)

    map = new Map({
      target: mapContainer.value,
      layers: [createWMTSLayer(DEFAULT_CONFIG.TIANDITU)],
      view: new View({
        center: DEFAULT_CONFIG.VIEW.CENTER,
        zoom: DEFAULT_CONFIG.VIEW.ZOOM,
        projection
      }),
      controls: []
    })

    // 控制地图最大最小缩放级别
    map.on('zoom', (event) => {
      if (event.target.getZoom() < DEFAULT_CONFIG.VIEW.MIN_ZOOM) {
        event.target.setZoom(DEFAULT_CONFIG.VIEW.MIN_ZOOM)
      }
      if (event.target.getZoom() > DEFAULT_CONFIG.VIEW.MAX_ZOOM) {
        event.target.setZoom(DEFAULT_CONFIG.VIEW.MAX_ZOOM)
      }
    })
    // 监听地图移动和鼠标移动事件
    map.on('moveend', updateCoordinates)
    map.on('pointermove', updateCoordinates)
    updateCoordinates()
  }
})

onUnmounted(() => {
  if (map) {
    map.setTarget(null)
    map = null
  }
})
</script>

<style scoped></style>
