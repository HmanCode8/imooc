<script setup>
import { ref, defineAsyncComponent, provide } from 'vue'
import DashboardLayout from './components/DashboardLayout.vue'
import OlMap from './components/OlMap.vue'
import CesiumMap from './components/CesiumMap.vue'
import Tabs from './components/Tabs.vue'
import ChartPreview from './components/charts/ChartPreview.vue'
import { TAB_COMPONENTS } from './components/tabs/index.js'
import { useChartPreview } from './hooks/useChartPreview.js'

// 当前激活的tab
const activeTab = ref('pipeOverview')
const mapType = ref('OL')
// 动态组件
const LeftComponent = ref(null)
const RightComponent = ref(null)

// 全局图表预览功能
const {
  isPreviewVisible,
  previewOption,
  previewTitle,
  previewDescription,
  previewChartType,
  showPreview,
  hidePreview,
  handleChartExport
} = useChartPreview()

// 提供全局预览功能给子组件
provide('chartPreview', {
  showPreview,
  hidePreview,
  handleChartExport
})

// 切换tab
const changeTab = async (tabValue) => {
  activeTab.value = tabValue

  // 动态加载对应的组件
  const tabComponents = TAB_COMPONENTS[tabValue]
  if (tabComponents) {
    LeftComponent.value = defineAsyncComponent(tabComponents.left)
    RightComponent.value = defineAsyncComponent(tabComponents.right)
  }
}

// 初始化默认tab
changeTab(activeTab.value)

const changeMapType = (key) => {
  mapType.value = key
}
</script>

<template>
  <DashboardLayout @changeMapType="changeMapType">
    <!-- 头部tabs -->
    <template #top-tabs>
      <Tabs @changeTab="changeTab" />
    </template>

    <!-- 左侧面板内容 -->
    <template #left-panel>
      <component :is="LeftComponent" v-if="LeftComponent" />
    </template>

    <!-- 地图区域内容 -->
    <template #map>
      <CesiumMap v-if="mapType === 'THREE_D'" />
      <OlMap v-if="mapType !== 'THREE_D'" />
    </template>

    <!-- 右侧面板内容 -->
    <template #right-panel>
      <component :is="RightComponent" v-if="RightComponent" />
    </template>

    <!-- 全局图表预览组件 -->
    <template #chart-preview>
      <ChartPreview :visible="isPreviewVisible" :option="previewOption" :title="previewTitle"
        :description="previewDescription" :chartType="previewChartType" @close="hidePreview"
        @export="handleChartExport" />
    </template>
  </DashboardLayout>
</template>

<!-- 所有样式都使用 Tailwind CSS 类，无需自定义 CSS -->
