// 开发环境配置
window.GLOBAL_CONFIG = {
  // 系统配置
  SYSTEM: {
    TITLE: '大数据可视化展平台'
  },
  // API 配置
  API: {
    BASE_URL: 'http://localhost:3000/api',
    TIMEOUT: 10000,
    DEBUG: true
  },

  // 地图配置
  MAP: {
    CONFIG: {
      // 江苏地区范围
      EXTENT: [116.10358013377254, 30.710719079012677, 122.09030402444137, 35.21265930204362],
      // 分辨率配置
      RESOLUTIONS: [
        1.406250026231578, 0.703125013115789, 0.3515625065578945, 0.17578125327894775,
        0.08789062663947399, 0.043945313319736994, 0.021972656659868472, 0.010986328329934226,
        0.005493164164967124, 0.0027465820824835504, 0.0013732910412417797, 0.0006866455206208899,
        0.0003433227603104438, 0.0001716613801552224, 0.00008583069007761132,
        0.00004291534503880566, 0.000021457672519402802, 0.000010728836259701401,
        0.000005364418129850712, 0.000002682209064925356, 0.000001341104532462678
      ],
      CGCS2000: {
        CODE: 'EPSG:4490',
        DEFINITION: '+proj=longlat +datum=CGCS2000 +no_defs'
      },
      // Web Mercator
      WEB_MERCATOR: {
        CODE: 'EPSG:3857',
        DEFINITION:
          '+proj=merc +a=6378137 +b=6378137 +lat_ts=0.0 +lon_0=0.0 +x_0=0.0 +y_0=0 +k=1.0 +units=m +nadgrids=@null +wktext +no_defs'
      },
      // 原点配置
      ORIGIN: [-180, 90],
      // 默认中心点
      DEFAULT_CENTER: [120.0, 32.8], // 江苏大致中心
      DEFAULT_ZOOM: 8,

      // 最小/最大缩放级别
      MIN_ZOOM: 0,
      MAX_ZOOM: 20
    },
    LAYER_CONFIGS: {
      URL: 'http://jiangsu.tianditu.gov.cn/historyraster/rest/services/historyVector/js_sldt_blue/MapServer/WMTS',
      LAYER: 'historyVector_js_sldt_blue',
      MATRIX_SET: 'default',
      STYLE: 'default',
      FORMAT: 'image/png',
      TITLE: '历史矢量-蓝色'
    },
    TILE_URL: 'http://localhost:8080/tiles',
    DEBUG: true
  },

  // 图表配置
  CHART: {
    ANIMATION: true,
    DEBUG: true
  }
}
